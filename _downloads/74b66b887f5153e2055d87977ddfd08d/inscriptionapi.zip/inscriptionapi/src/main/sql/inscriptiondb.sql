drop table if exists Inscription;

create table Inscription (
  id int primary key auto_increment,
  nom varchar(100) not null,
  dateInscription date not null
) engine = InnoDB;