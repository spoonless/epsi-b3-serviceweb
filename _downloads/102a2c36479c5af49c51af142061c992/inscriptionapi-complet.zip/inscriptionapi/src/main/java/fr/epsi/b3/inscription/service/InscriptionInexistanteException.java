package fr.epsi.b3.inscription.service;

public class InscriptionInexistanteException extends Exception {

	public InscriptionInexistanteException() {
		super("L'inscription n'existe pas !");
	}
}
