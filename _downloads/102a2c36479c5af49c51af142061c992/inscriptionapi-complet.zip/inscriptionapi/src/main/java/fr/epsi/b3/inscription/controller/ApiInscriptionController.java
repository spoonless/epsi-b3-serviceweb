package fr.epsi.b3.inscription.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import fr.epsi.b3.inscription.model.Inscription;
import fr.epsi.b3.inscription.service.DonneesPersonnellesDto;
import fr.epsi.b3.inscription.service.InscriptionInexistanteException;
import fr.epsi.b3.inscription.service.InscriptionService;
import fr.epsi.b3.inscription.service.PersonneMineureException;

@RestController
@RequestMapping("/api/inscription")
public class ApiInscriptionController {
	
	@Autowired
	private InscriptionService inscriptionService;
	
	@ExceptionHandler(PersonneMineureException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public ErreurDto handlePersonneMineureException(PersonneMineureException e) {
		return new ErreurDto(e);
	}
	
	@ExceptionHandler(InscriptionInexistanteException.class)
	@ResponseStatus(code = HttpStatus.NOT_FOUND)
	public ErreurDto handleInscriptionInexistanteException(InscriptionInexistanteException e) {
		return new ErreurDto(e);
	}

	@PostMapping(path="/", produces = "application/json", consumes="application/json")
	public ResponseEntity<Inscription> create(@RequestBody DonneesPersonnellesDto donneesPersonnellesDto, UriComponentsBuilder uriBuilder) throws PersonneMineureException {
		Inscription inscription = inscriptionService.inscrire(donneesPersonnellesDto);
		URI uri = uriBuilder.path("/api/inscription/" + inscription.getId()).build().toUri();
		return ResponseEntity.created(uri).body(inscription);
	}
	
	@GetMapping(path="/{idInscription}", produces = "application/json")
	public Inscription getById(@PathVariable long idInscription) throws InscriptionInexistanteException {
		return inscriptionService.getById(idInscription);
	}
	
	@DeleteMapping(path="/{idInscription}")
	public ResponseEntity<Inscription> delete(@PathVariable long idInscription) {
		inscriptionService.deleteById(idInscription);
		return ResponseEntity.noContent().build();
	}
	
	@PutMapping(path="/{idInscription}", produces = "application/json", consumes = "application/json")
	public Inscription update(@PathVariable long idInscription, @RequestBody DonneesPersonnellesDto donneesPersonnellesDto) throws InscriptionInexistanteException {
		return inscriptionService.update(idInscription, donneesPersonnellesDto.getNom());
	}
	
}
