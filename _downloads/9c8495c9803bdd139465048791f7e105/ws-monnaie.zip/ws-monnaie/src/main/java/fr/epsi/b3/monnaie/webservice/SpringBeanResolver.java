package fr.epsi.b3.monnaie.webservice;

import javax.servlet.ServletContext;
import javax.xml.ws.handler.MessageContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sun.istack.NotNull;
import com.sun.xml.ws.api.message.Packet;
import com.sun.xml.ws.api.server.InstanceResolver;

/**
 * Intégration de Spring dans l'implémentation Sun de JAX-WS.
 * 
 * @author David Gayerie
 */
public class SpringBeanResolver<T> extends InstanceResolver<T> {

	private Class<T> clazz;

	public SpringBeanResolver(Class<T> clazz) {
		this.clazz = clazz;
	}

	@Override
	public @NotNull T resolve(Packet request) {
		ServletContext sc = (ServletContext) request.get(MessageContext.SERVLET_CONTEXT);
		WebApplicationContext context = WebApplicationContextUtils.findWebApplicationContext(sc);
		return context.getBean(clazz);
	}
}
