package fr.epsi.b3.monnaie.webservice;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.stereotype.Component;

import com.sun.xml.ws.api.server.InstanceResolverAnnotation;

/**
 * Une annotation pour indiquer qu'un bean Spring est utilisable
 * comme SEI (Service Endpoint Implementation) d'un service JAX-WS.
 * 
 * @author David Gayerie
 *
 */
@Target(ElementType.TYPE)
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@InstanceResolverAnnotation(SpringBeanResolver.class)
@Component
public @interface WebServiceController {

}
