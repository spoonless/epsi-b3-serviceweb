package io.spoonless.springmvc;

public class User {
	
	private String name = "Gayerie";
	private String firstname = "David";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

}
