package io.spoonless.springmvc;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestControler {

	@GetMapping(path="/hello", produces= {"application/json", "application/xml"})
	public User sayHello() {
		return new User();
	}
	
}
